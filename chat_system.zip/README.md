# Chat System Documentation

## Overview
This project implements a chat system with two interfaces:
1. **User Chat Window**: A simple interface for regular users to communicate with support staff
2. **Support Chat Window**: A more complex interface for support staff to manage multiple user conversations

## Files Structure
- **HTML Files**:
  - `user_chat.html`: The interface for regular users
  - `support_chat.html`: The interface for support staff
  
- **CSS Files**:
  - `css/chat_styles.css`: Common styling for both interfaces
  - `css/support_styles.css`: Additional styling specific to the support interface
  
- **JavaScript Files**:
  - `js/user_chat.js`: jQuery functionality for the user interface
  - `js/support_chat.js`: jQuery functionality for the support interface with chat switching

## Features

### User Chat Window
- Clean, simple interface focused on one-on-one conversation
- Status indicator showing if support is online/offline
- Message history with visual distinction between sent and received messages
- Responsive design that works on both mobile and desktop devices
- Timestamps for all messages
- Auto-expanding text input area

### Support Chat Window
- Sidebar listing all active conversations with users
- Ability to switch between different user conversations
- Unread message indicators
- User information displayed in the current chat header
- Search functionality to find specific users or conversations
- Status indicators for each user
- Responsive design that adapts to different screen sizes

## Implementation Details

### User Interface
The user chat window is designed to be simple and intuitive. Users can type messages in the input area and send them by clicking the send button or pressing Enter. The interface shows a clear distinction between user messages (right-aligned with blue background) and support messages (left-aligned with gray background).

### Support Interface
The support chat window includes a sidebar with a list of all active conversations. Support staff can click on any user in the sidebar to switch to that conversation. The main chat area displays the current conversation with the selected user. The interface includes additional features like search functionality and user information display.

### Interactivity
Both interfaces use jQuery for interactivity:
- Message sending and receiving
- Auto-scrolling to the latest messages
- Dynamic updating of message history
- Chat switching in the support interface
- Search functionality in the support interface

### Responsiveness
Both interfaces are designed to be responsive and work well on various screen sizes:
- On mobile devices, the support interface collapses the sidebar into a more compact view
- Text and UI elements adjust to fit different screen widths
- Input areas and buttons remain accessible and usable on touch devices

## Usage Instructions

### For Users
1. Open `user_chat.html` in a web browser
2. Type your message in the input area at the bottom
3. Press Enter or click the send button to send your message
4. Wait for support to respond (responses will appear in the chat area)

### For Support Staff
1. Open `support_chat.html` in a web browser
2. View the list of active conversations in the sidebar
3. Click on a user to view and respond to their conversation
4. Use the search box to find specific users or conversations
5. Type your response in the input area and send it
6. Switch between different conversations as needed

## Technical Notes
- This implementation uses HTML, CSS, and jQuery as requested
- No backend implementation is included - in a real application, this would require server-side code
- The current implementation simulates message exchange locally
- For production use, this would need to be connected to a backend service with WebSockets or a similar technology for real-time communication
