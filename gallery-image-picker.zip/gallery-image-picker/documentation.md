# Gallery Image Picker and Uploader - Documentation

## Overview
This component provides a modal-based gallery image picker and uploader that can be easily integrated into any web application. Users can select images from a pre-existing gallery, upload new images, and manage their selections in a user-friendly interface.

## Features
- Modal-based interface for image selection and upload
- Gallery image selection with visual feedback
- Drag-and-drop file upload support
- Multiple image selection capability
- Preview of selected images
- Ability to remove selected images
- Responsive design for mobile and desktop
- Form submission with selected images

## File Structure
```
gallery-image-picker/
├── index.html           # Demo HTML file
├── css/
│   └── style.css        # Main stylesheet
├── js/
│   ├── gallery.js       # Main jQuery functionality
│   └── placeholder.js   # Placeholder image generator
└── assets/
    └── images/          # Directory for gallery images
```

## Usage Instructions

### Basic Integration
1. Include the required CSS and JavaScript files in your HTML:
```html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="path/to/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="path/to/placeholder.js"></script>
<script src="path/to/gallery.js"></script>
```

2. Add the modal HTML structure to your page:
```html
<!-- Button to open the modal -->
<button id="open-gallery-modal" class="btn btn-primary">Open Gallery Picker</button>

<!-- Container to display selected images -->
<div id="result-container" class="result-images"></div>

<!-- Modal Gallery Picker -->
<div id="gallery-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Gallery Image Picker & Uploader</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <div class="gallery-container">
                <h3>Select from Gallery</h3>
                <div class="gallery" id="image-gallery">
                    <!-- Gallery images will be loaded here -->
                    <div class="gallery-item" data-id="1">
                        <img src="path/to/image1.jpg" alt="Gallery Image 1">
                        <div class="overlay">
                            <i class="fas fa-check"></i>
                        </div>
                    </div>
                    <!-- Add more gallery items as needed -->
                </div>
            </div>
            
            <div class="upload-container">
                <h3>Upload New Images</h3>
                <div class="upload-area" id="upload-area">
                    <div class="upload-instructions">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>Drag & drop images here or</p>
                        <label for="file-input" class="upload-btn">Browse Files</label>
                        <input type="file" id="file-input" multiple accept="image/*">
                    </div>
                </div>
            </div>
            
            <div class="preview-container">
                <h3>Selected Images</h3>
                <div class="preview-area" id="preview-area">
                    <p class="no-images">No images selected</p>
                    <!-- Selected images will appear here -->
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button id="clear-selection" class="btn btn-danger">Clear Selection</button>
            <button id="submit-selection" class="btn btn-primary">Apply Selection</button>
        </div>
    </div>
</div>
```

### Customization Options

#### Styling
You can customize the appearance by modifying the CSS variables at the top of the `style.css` file:

```css
:root {
    --primary-color: #4a6cf7;
    --secondary-color: #6c757d;
    --success-color: #28a745;
    --danger-color: #dc3545;
    --light-color: #f8f9fa;
    --dark-color: #343a40;
    --border-radius: 8px;
    --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    --transition: all 0.3s ease;
}
```

#### Gallery Images
To populate the gallery with your own images:

1. Replace the placeholder images in the HTML with your own images
2. Update the `data-id` attributes to match your image identifiers

#### Form Submission
To handle form submission with the selected images, modify the `submit-selection` click handler in `gallery.js`:

```javascript
$("#submit-selection").on("click", function() {
    const allImages = [...selectedGalleryImages, ...uploadedImages];
    
    // Create FormData object
    const formData = new FormData();
    
    // Add selected gallery images (by ID)
    selectedGalleryImages.forEach(image => {
        formData.append('gallery_images[]', image.id);
    });
    
    // Add uploaded files
    uploadedImages.forEach(image => {
        formData.append('uploaded_images[]', image.file);
    });
    
    // Send to server
    $.ajax({
        url: 'your-server-endpoint',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            console.log('Success:', response);
        },
        error: function(error) {
            console.error('Error:', error);
        }
    });
    
    // Close modal
    closeModal();
});
```

## Browser Compatibility
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Android Chrome)

## Dependencies
- jQuery 3.6.0+
- Font Awesome 6.4.0+ (for icons)

## License
This component is provided for free use in both personal and commercial projects.
